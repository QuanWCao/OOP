package lab6.ex1.ex2;

public class TestPerSon {

    public static void main(String[] args) {

        Student student1 = new Student("Quan", "Dong Anh", "Vippro", 2022, 0);
        System.out.println(student1);

        Staff staff1 = new Staff("Abc", "Ha Noi", "Ga", 0);
        System.out.println(staff1);
    }

}

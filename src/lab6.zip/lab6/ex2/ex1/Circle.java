package lab6.e;

public class Circle {
}

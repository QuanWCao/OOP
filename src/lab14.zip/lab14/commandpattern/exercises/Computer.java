package lab14.commandpattern.exercises;

import java.util.List;

public class Computer {


    public void restart() {
        System.out.println("The computer restart");
    }

    public void shutdown() {
        System.out.println("The computer shutdown");
    }
}

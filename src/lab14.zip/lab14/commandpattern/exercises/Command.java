package lab14.commandpattern.exercises;

public interface Command {

    void execute();
}

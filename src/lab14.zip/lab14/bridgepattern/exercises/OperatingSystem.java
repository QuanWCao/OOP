package lab14.bridgepattern.exercises;

public interface OperatingSystem {

    void startup();

    void load(String url);
}

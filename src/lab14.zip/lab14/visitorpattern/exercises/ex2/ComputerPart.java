package lab14.visitorpattern.exercises.ex2;

public interface ComputerPart {
    void accept(ComputerPartVisitor v);
}

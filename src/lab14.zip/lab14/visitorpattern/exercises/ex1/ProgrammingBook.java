package lab14.visitorpattern.exercises.ex1;

public interface ProgrammingBook extends Book {
    String getResource();
}

package lab14.visitorpattern.exercises.ex1;

public interface Book {
    void accept(Visitor v);
}

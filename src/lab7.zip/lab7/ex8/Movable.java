package lab7.ex8;

public interface Movable {

    void moveUp();

    void moveDown();

    void moveLeft();

    void moveRight();


}

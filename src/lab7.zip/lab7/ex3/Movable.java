package lab7.ex3;

public interface Movable {

    void moveUp();

    void moveDown();

    void moveLeft();

    void moveRight();
}

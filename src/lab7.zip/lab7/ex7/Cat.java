package lab7.ex7;

public class Cat extends Animal {


    @Override
    public void greeting() {
        System.out.println("Meow!");
    }
}

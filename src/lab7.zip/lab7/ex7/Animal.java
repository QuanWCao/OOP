package lab7.ex7;

abstract public class Animal {

    abstract public void greeting();
}

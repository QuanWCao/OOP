package lab7.ex2;

public interface GeometricObject {

    double getArea();

    double getPerimeter();
}

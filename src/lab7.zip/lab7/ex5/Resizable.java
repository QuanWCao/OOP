package lab7.ex5;

public interface Resizable {

    void resize(int percent);
}

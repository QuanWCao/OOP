package lab7.ex5;

public interface GeometricObject {

    double getArea();

    double getPerimeter();
}

package lab13.example.decoratorpattern.ex2;

public class StrawberryIceCream implements IceCream {
    @Override
    public String getDescription() {
        return "StrawberryIceCream";
    }
}

package lab13.example.decoratorpattern.ex2;

public interface IceCream {

    String getDescription();
}

package lab13.example.decoratorpattern.ex2;

public class ChocolateIceCream implements IceCream {
    @Override
    public String getDescription() {
        return "ChocolateIceCream";
    }
}

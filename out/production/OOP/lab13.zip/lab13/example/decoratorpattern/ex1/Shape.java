package lab13.example.decoratorpattern.ex1;

public interface Shape {

    void draw();
}

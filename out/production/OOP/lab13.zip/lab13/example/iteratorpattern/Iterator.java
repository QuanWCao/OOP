package lab13.example.iteratorpattern;

public interface Iterator {

    public boolean hasNext();

    public Object next();
}

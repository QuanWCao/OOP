package lab13.example.iteratorpattern;

public interface Iterable {

    Iterator getIterator();
}

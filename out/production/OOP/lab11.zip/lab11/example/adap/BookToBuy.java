package lab11.example.adap;

public class BookToBuy {

    private double priceToBuy;

    public BookToBuy(double priceToBuy) {
        this.priceToBuy = priceToBuy;
    }

    public double getPriceToBuy() {
        return priceToBuy;
    }

}

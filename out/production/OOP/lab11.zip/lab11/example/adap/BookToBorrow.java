package lab11.example.adap;

public class BookToBorrow {

    private double priceBorrow;

    public BookToBorrow(double priceBorrow) {
        this.priceBorrow = priceBorrow;
    }

    public double getPriceBorrow() {
        return priceBorrow;
    }
}

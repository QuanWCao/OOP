package lab11.example.strategy;

public interface Animal {

    void greets();


}

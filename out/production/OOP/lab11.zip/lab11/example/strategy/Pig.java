package lab11.example.strategy;

public class Pig implements Animal {
    @Override
    public void greets() {
        System.out.println("Uggggggg");
    }


}

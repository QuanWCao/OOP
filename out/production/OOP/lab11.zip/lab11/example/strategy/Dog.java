package lab11.example.strategy;

public class Dog implements Animal {

    @Override
    public void greets() {
        System.out.println("Gauu");
    }


}

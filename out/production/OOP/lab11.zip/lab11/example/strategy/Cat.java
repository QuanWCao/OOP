package lab11.example.strategy;

public class Cat implements Animal {

    @Override
    public void greets() {
        System.out.println("Meow");

    }


}

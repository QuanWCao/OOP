package lab11.strategy;

public interface Strategy {

    int execute(int a, int b);
}
